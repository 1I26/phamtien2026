"use strict"
window.addEventListener("DOMContentLoaded", function () {
    let popMessage = "いらっしゃい！おみくじ引いてって！";
    window.alert(popMessage);
}, false
);

const btn1 = document.getElementById("btn1");
btn1.addEventListener("click", function () {
    let n = Math.floor(Math.random() * 3);

    // style reset
    btn1.style.color = "";
    btn1.style.fontSize = "";
    btn1.style.fontFamily = "";
    btn1.style.fontWeight = "";
    btn1.style.fontStyle = "";
    btn1.style.transform = "";

    switch (n) {
        case 0:
            btn1.textContent = "Very Happy!!";
            btn1.style.color = "red";
            btn1.style.fontSize = "35px";
            btn1.style.fontFamily = "Arial";
            btn1.style.fontWeight = "bold";
            btn1.style.fontStyle = "italic";
            break;
        case 1:
            btn1.textContent = "Happy!";
            btn1.style.color = "green";
            btn1.style.fontSize = "42px";
            break;
        case 2:
            btn1.textContent = "UnHappy...";
            btn1.style.color = "black";
            btn1.style.fontSize = "28px";
            btn1.style.transform = "scaleX(-1)";
            break;
            
            
    }
}, false);
