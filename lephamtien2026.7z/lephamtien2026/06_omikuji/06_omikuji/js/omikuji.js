"use strict"
window.addEventListener("DOMContentLoaded", function () {
    let popMessage = "いらっしゃい！おみくじ引いてって！";
    window.alert(popMessage);
}, false
);